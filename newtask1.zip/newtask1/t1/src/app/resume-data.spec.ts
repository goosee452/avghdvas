import { ResumeData } from './resume-data';

describe('ResumeData', () => {
  it('should create an instance', () => {
    expect(new ResumeData()).toBeTruthy();
  });
});
