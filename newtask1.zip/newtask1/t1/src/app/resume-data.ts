export class ResumeData {
    email: string;
    phone_number: string;
    full_name: string;

    constructor(){
        this.email = '';
        this.phone_number = '';
        this.full_name = '';
    }
}
