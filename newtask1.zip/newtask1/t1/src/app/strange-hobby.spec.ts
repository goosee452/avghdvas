import { StrangeHobby } from './strange-hobby';

describe('StrangeHobby', () => {
  it('should create an instance', () => {
    expect(new StrangeHobby()).toBeTruthy();
  });
});
