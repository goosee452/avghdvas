import { Component, OnInit } from '@angular/core';
import { ResumeData } from '../resume-data';

@Component({
  selector: 'app-resume',
  templateUrl: './resume.component.html',
  styleUrl: './resume.component.css'
})
export class ResumeComponent implements OnInit{
  constructor(){

  }

  ngOnInit(): void {
    
  }

  resumeData: ResumeData = {
    full_name: 'Ivan Drobovik',
    email: 'iaooi@gmail.com',
    phone_number: '+375 29 127-32-11'
  }
}
