export class StrangeHobby {
    descr: string;
    name: string;

    constructor(){
        this.descr = '';
        this.name = '';
    }
}
