import { Component, OnInit } from '@angular/core';
import { StrangeHobby } from '../strange-hobby';

@Component({
  selector: 'app-hobby',
  templateUrl: './hobby.component.html',
  styleUrl: './hobby.component.css'
})
export class HobbyComponent implements OnInit{
  constructor(){
  }

  ngOnInit(): void {
    console.log('ngOnInit was just called');
  }
  
  strHobby: StrangeHobby = {
    name: 'Joking',
    descr: `'Accidentally' dropping thermonuclear bomb blueprints in public places`
  }
}
